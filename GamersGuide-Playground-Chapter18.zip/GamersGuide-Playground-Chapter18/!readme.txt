Playground Scripts
Chapter 18 > Using Numbers and Math in Games

These JavaScript examples are described in the book _The Gamer's Guide to Coding_. 
Commenting is limited in the code files; refer to the book for explanations of what's going on in 
the code, and how it works. Downloads are organized by chapter. 

All code is open source and provided under the Creative Commons 4.0 Sharealike license. See 
https://creativecommons.org/licenses/by-sa/4.0/ for more information.

